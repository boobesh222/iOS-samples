//
//  CustomCollectionViewCell.swift
//  multipleImagePIckerFramework
//
//  Created by IPhone Dev on 25/05/17.
//  Copyright © 2017 Sensiple. All rights reserved.
//

import Foundation
import Photos

class CustomCollectionViewCell:UICollectionViewCell{

    var imageAssests:PHAsset?{
        didSet{
            self.photomanager?.requestImage(for: imageAssests!, targetSize:CGSize(width: 320, height: 320) , contentMode: .aspectFit, options: nil, resultHandler: {(resultImage,info ) in self.Photos.image = resultImage })
        }
    }
    var photomanager:PHImageManager?
   
    
    @IBOutlet weak var Photos: UIImageView!
}
