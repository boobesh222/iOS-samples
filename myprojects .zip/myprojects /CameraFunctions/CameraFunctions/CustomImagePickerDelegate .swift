//
//  CustomImagePickerDelegate .swift
//  CameraFunctions
//
//  Created by IPhone Dev on 23/05/17.
//  Copyright © 2017 Sensiple. All rights reserved.
//

import Foundation
import UIKit

protocol CustomImagePickerDelegate  {
    func selectedPhotoLibraryImage(selectedImage:UIImage)
}
