//
//  ViewController.swift
//  BarcodeScanner
//
//  Created by Boobesh Balasubramanian on 26/04/17.
//  Copyright © 2017 sensiple. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    
    var barcode:BarcodeScanner?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        barcode = BarcodeScanner()
        barcode?.setupCamera(previewViewForScanning: self.view)
    
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        barcode?.startScanningSessionForBarcodes()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        barcode?.stopScanningSessionForBarcodes()
    
    }
    
    
}

