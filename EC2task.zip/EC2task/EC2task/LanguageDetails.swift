//
//  LanguageDetails.swift
//  EC2task
//
//  Created by Boobesh Balasubramanian on 10/09/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import ObjectMapper

class LanguageJsonDetails:Mappable{

    var category:String?
    var created_by:Int?
    var created_date:Date?
    var id:String?
    var key:String?
    var language_code:String?
    var last_updated_date:Date?
    var updated_by:Int?
    var value:String?
    
    required init?(map: Map){
        
    }
    
    func mapping(map: Map) {
        category <- map["category"]
        created_by <- map["created_by"]
        created_date <- map["created_date"]
        id <- map["id"]
        key <- map["key"]
        language_code <- map["language_code"]
        last_updated_date <- map["last_updated_date"]
        updated_by <- map["updated_by"]
        value <- map["value"]

        
    }
    
}
