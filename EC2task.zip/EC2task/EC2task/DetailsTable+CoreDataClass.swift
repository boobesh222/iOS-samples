//
//  DetailsTable+CoreDataClass.swift
//  EC2task
//
//  Created by Boobesh Balasubramanian on 10/09/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import CoreData


public class DetailsTable: NSManagedObject {

}
