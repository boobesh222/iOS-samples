//
//  File.swift
//  CameraFunctions
//
//  Created by Boobesh Balasubramanian on 19/05/17.
//  Copyright © 2017 Sensiple. All rights reserved.
//

import Foundation
import UIKit


/* implements UIImage picker controller for picking image from photolibrary
   supports selecting only one image per request */

class ImagePickerHelper:NSObject,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    
    public let imagePicker = UIImagePickerController()
    public var ImagePickerProtocol:CustomImagePickerDelegate?
    
    // sets up image picker controller delegate
    public func setupImagePickerDelegate(){
        imagePicker.delegate = self
    }
    
    // loads the imagepicker model and editing is optional with this method
    public func loadImagePicker(presentingViewController:ViewController,needsEditing editingOption:Bool){
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = editingOption
        presentingViewController.present(imagePicker, animated: true, completion: nil)
    }
    
    // picker delegate method which returns the only one selected image
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if (imagePicker.allowsEditing){
            if let EditedImage = info[UIImagePickerControllerEditedImage] as? UIImage{
                print(EditedImage.size)
                ImagePickerProtocol?.selectedPhotoLibraryImage(selectedImage: EditedImage)
                picker.dismiss(animated: true, completion: nil)
            }
        }else{
            if let originalImage = info[UIImagePickerControllerOriginalImage] as? UIImage{
                print(originalImage.size)
                ImagePickerProtocol?.selectedPhotoLibraryImage(selectedImage: originalImage)
                picker.dismiss(animated: true, completion: nil)

            }
        }
        
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
}



/*    UIView* backgroundView = [[UIView alloc] initWithFrame:self.bounds];
    backgroundView.backgroundColor = [UIColor redColor];
    self.backgroundView = backgroundView;
    UIView* selectedBGView = [[UIView alloc] initWithFrame:self.bounds];
    selectedBGView.backgroundColor = [UIColor whiteColor];
    self.selectedBackgroundView = selectedBGView;*/


