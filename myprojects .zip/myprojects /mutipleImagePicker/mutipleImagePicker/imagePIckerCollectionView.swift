//
//  imagePIckerCollectionView.swift
//  multipleImagePIckerFramework
//
//  Created by Boobesh Balasubramanian  on 24/05/17.
//  Copyright © 2017 Sensiple. All rights reserved.
//

import Foundation
import Photos

class ImagePickerCollectionView:UIViewController,UICollectionViewDataSource, UICollectionViewDelegate,PHPhotoLibraryChangeObserver{
    
    var images:PHFetchResult<PHAsset>?
    let imageManager = PHCachingImageManager()
    
    
    func fetchMediaAssets() {
        images = PHAsset.fetchAssets(with: .image, options: nil)
        print("images assests count \(images?.count)")
        PHPhotoLibrary.shared().register(self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        print("view did load ")
        fetchMediaAssets()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        print("didReceiveMemoryWarning")

    }

    
    /* collection view delegate  methods*/
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (images?.count)!
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("item selected at \(indexPath.row)")
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "albumImage", for: indexPath) as! CustomCollectionViewCell
        cell.imageAssests = images?[indexPath.item]
        
        return cell
    }
    
    
    /* photo library delegate methods which handle the changes  */
    
    func photoLibraryDidChange(_ changeInstance: PHChange){
        
    }
    
}
