//
//  ViewController.swift
//  EC2task
//
//  Created by Boobesh Balasubramanian on 10/09/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireObjectMapper

class ViewController: UIViewController{

    var jsonData:Any?
    //var languagesList:[Any?]
    var languagesNames = [String]()
    var languagesIds = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        readDataFromConfigFile { (data) in
            let languagesList = (data as? [[String:Any]])!
            for languages in languagesList {
                if let name = languages["name"] as? String{
                   languagesNames.append(name)
                }
                
                if let id = languages["id"] as? String{
                    languagesIds.append(id)
                }
            }
        }
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // reads data from the json configuration file
    func readDataFromConfigFile(completionHandler:(Any?)->()){
        do{
            
        let path = Bundle.main.path(forResource: "language", ofType: "json")
        let json = try NSData(contentsOfFile: path!, options: NSData.ReadingOptions.mappedIfSafe)
        jsonData = try JSONSerialization.jsonObject(with: json as Data, options: JSONSerialization.ReadingOptions.allowFragments)
            
           completionHandler(jsonData)
        }catch {
           print("Error in reading config file ")
        }
        
    }
    
    func getDetailsForLanguages(choosedlanguageId:String){
        let URL = "https://d325ty7uqiufcm.cloudfront.net/ikea/v1/api/transla ons?where=language_code+is+\(choosedlanguageId)&where =category+is+welcome&limit=1000"
        Alamofire.request(URL).responseObject { (response: DataResponse<LanguageJsonDetails>) in
            
            let languageDetailsInResponse = response.result.value
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    

}

extension ViewController:UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var languageid = languagesIds[indexPath.row]
    }
}

extension ViewController:UITableViewDataSource{

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return languagesNames.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"languageTableViewCell" , for: indexPath)
        cell.textLabel?.text = languagesNames[indexPath.row]
        return cell
        
    }
}
