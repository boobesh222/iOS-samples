//
//  AppDelegate.h
//  i_trackbus
//
//  Created by Boobesh on 7/7/16.
//  Copyright © 2016 chehkra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

