//
//  BarcodeScanner.swift
//  BarcodeScanner
//
//  Created by Boobesh Balasubramanian on 02/05/17.
//  Copyright © 2017 sensiple. All rights reserved.
//

import Foundation
import AVFoundation
import UIKit

class BarcodeScanner:NSObject,AVCaptureMetadataOutputObjectsDelegate{
    
    var videoCaptureDevice: AVCaptureDevice = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
    var device = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
    var captureInput:AVCaptureDeviceInput?
    var metadataOutput = AVCaptureMetadataOutput()
    var previewLayer: AVCaptureVideoPreviewLayer?
    var captureSession:AVCaptureSession?
    var code: String?
    //var barcodehighlightingView:UIView?
    var parentView:UIView?
    var qrCodeFrameView:UIView?
    var audioPlayer:AVAudioPlayer?
    //typealias cameraSetupCompletionHandler = ()->Void
    var barcodeProtocol:barcodeResultProtocol?
    
    override init() {
        captureSession = AVCaptureSession()
        self.previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
    }
    
    /* Function which setup the camera for scanning the one and 2 dimentional barcodes and supports the 13 Symbolizes according to apple documentation   */
    
    internal func setupCamera(previewViewForScanning:UIView,frameWidth:Int,frameHeight:Int,frameColour:CGColor){
        
        parentView = previewViewForScanning
        captureInput = try? AVCaptureDeviceInput(device: videoCaptureDevice)
        
        if (self.captureSession?.canAddInput(captureInput))! {
            self.captureSession?.addInput(captureInput)
        }
        
        if (previewLayer?.connection.isEnabled )!{
            print("preview layer enabled ")
        }else{
            print("layer not enabled ")
            previewLayer?.connection.isEnabled=true
        }
        
        /*  frame size customization logic  */
        let minFrameWidth  = 150
        let maxFramewidth  = 150
        let minFrameHeight = 400
        let maxFrameHeight = 400
        
        if ((frameWidth<maxFramewidth && frameWidth>minFrameWidth)&&(frameHeight<maxFrameHeight&&frameHeight>minFrameHeight)){
            drawBarcodeFocusingArea(Width: frameWidth, height: frameHeight,colour: frameColour)
            
        }else{
            let frameWidth = minFrameWidth
            let frameHeight = minFrameHeight
           drawBarcodeFocusingArea(Width: frameWidth, height: frameHeight, colour: frameColour)
        }
            
            
        
        if let videoPreviewLayer = self.previewLayer {
            videoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
            videoPreviewLayer.frame = (parentView?.bounds)!
            parentView?.layer.addSublayer(videoPreviewLayer)
            
        }
        
        print("camera setted up")
        metadataOutput = AVCaptureMetadataOutput()
        if (self.captureSession?.canAddOutput(metadataOutput))! {
            self.captureSession?.addOutput(metadataOutput)
            
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            print("metadata output delegate added ")
            metadataOutput.metadataObjectTypes = [AVMetadataObjectTypeUPCECode,
                                                  AVMetadataObjectTypeCode39Code,
                                                  AVMetadataObjectTypeCode39Mod43Code,
                                                  AVMetadataObjectTypeEAN8Code,
                                                  AVMetadataObjectTypeCode93Code,
                                                  AVMetadataObjectTypeCode128Code,
                                                  AVMetadataObjectTypePDF417Code,
                                                  AVMetadataObjectTypeAztecCode,
                                                  AVMetadataObjectTypeInterleaved2of5Code,
                                                  AVMetadataObjectTypeITF14Code,
                                                  AVMetadataObjectTypeDataMatrixCode,
                                                  AVMetadataObjectTypeQRCode,
                                                  AVMetadataObjectTypeEAN13Code]
            
        }else {
            print("Could not add metadata output")
        }
        
        
        
    }
    
    
    /* consecutive methods which starts and stops barcode scanning sessions  */
    
    func startScanningSessionForBarcodes(){
        let captureSessionSerialQueue = DispatchQueue(label: "captureSessionQueue")
        captureSessionSerialQueue.sync {
            if (captureSession?.isRunning == false) {
                captureSession?.startRunning();
                print("session started")
            }
        }
        
    }
    
    func stopScanningSessionForBarcodes(){
        if (captureSession?.isRunning == true) {
            captureSession?.stopRunning();
        }
    }
    
    /* delegate method which returns the captured output objects */
    
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!){
        
        var resultBarcode:String?
        previewLayer?.connection.isEnabled = false
        self.captureSession?.removeOutput(metadataOutput)
        self.captureSession?.removeInput(captureInput)
        
        
        // stop the scanning when its only one time scanning use else dont stop it
        // stopScanningSessionForBarcodes()
        
        playSound()
        
        // remove the added subview and return the superviews
        self.previewLayer?.removeFromSuperlayer()
        self.qrCodeFrameView?.removeFromSuperview()
        
        for metadata in metadataObjects {
            let readableObject = metadata as! AVMetadataMachineReadableCodeObject
            resultBarcode = readableObject.stringValue
            qrCodeFrameView?.frame = readableObject.bounds
            print(resultBarcode!)
            barcodeProtocol?.scannedBarcodeResult(resultBarcode!)
            
        }
        
    }
    
    
    /*  Gives sound feedback after detecting the barcode/qrcodes  */
    func playSound() {
        let soundFilePath = Bundle.main.path(forResource:"beep",ofType:"mp3")
        let fileURL = NSURL(string: soundFilePath!)! as URL
        print("trying to play the sound  @ \(String(describing: fileURL))")
        //var error: NSError?
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: fileURL)
            audioPlayer!.play()
            audioPlayer!.volume = 1.0
        }catch {
            print ("error in playing sound ")
        }
    }
    
    
    /* this method  draws highlighting barcode for the focusing area   */
    /* creating  frameview  */
    /* the corresponding method requires width and height of the center focussing area and aswell the highlighting colour has the default min and max width and height*/
    func drawBarcodeFocusingArea(Width:Int,height:Int,colour:CGColor){
        
        
        qrCodeFrameView = UIView()
        if let qrCodeFrameView = qrCodeFrameView {
            qrCodeFrameView.layer.borderColor = UIColor.red.cgColor
            qrCodeFrameView.layer.borderWidth = 2
            qrCodeFrameView.frame = CGRect(x:0.0, y:0.0, width:250, height:250)
            qrCodeFrameView.layer.zPosition = 1
            qrCodeFrameView.center = CGPoint(x:(parentView?.frame.size.width)!  / 2,
                                             y:(parentView?.frame.size.height)! / 2);
            parentView?.addSubview(qrCodeFrameView)
            parentView?.bringSubview(toFront: qrCodeFrameView)
            
        }
        
    }
}


/* iterate sub views recursively and remove it */

//        parentView?.subviews.forEach(){
//            print($0)
//              $0.removeFromSuperview()
//        }

/* shows the result of barcodes  in alertview  */
// should be moved under callback
/*func scannedResultAlert(scannedCode:String){
 let userIntimationAlert=UIAlertController(title: "yeppie ", message: "find your code \(scannedCode)", preferredStyle: .alert)
 userIntimationAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
 callingViewController!.present(userIntimationAlert, animated: true)
 }*/

