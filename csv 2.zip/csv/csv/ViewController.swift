//
//  ViewController.swift
//  csv
//
//  Created by Boobesh Balasubramanian on 14/03/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UIGestureRecognizerDelegate {
    
    /*Collection of outlets and actions for the matched view controller  */
    
    
    @IBOutlet weak var FirstNameTextfield: UITextField!
    @IBOutlet weak var LastNameTextField: UITextField!
    @IBOutlet weak var TitleTextField: UITextField!
    @IBOutlet weak var PhoneNumberTextField: UITextField!
    @IBOutlet weak var EmailAddressTextField: UITextField!
    @IBOutlet weak var Company: UITextField!
    @IBOutlet weak var ListOfProductsLabel: UILabel!
    @IBOutlet weak var DeploymentTypeLabel: UILabel!
    @IBOutlet weak var OrganisationTypeLabel: UILabel!
    @IBOutlet weak var TimeFrameLabel: UILabel!
    @IBOutlet weak var NotesTextField: UITextView!
    @IBOutlet weak var AccountTypeLabel: UILabel!
    @IBOutlet weak var UrgencyTypeLabel: UILabel!
    
    @IBAction func SubmitFormButton(_ sender: UIButton) {
        
        
    }
    
    
    
    /* Datasource array's for the picker view  */
    
    let IManageProducts = ["iManage work", "iManage Share"," iManage Insight", "iManage govern" , "MFP integration", "Process Automation"]
    let DeploymentTypes = ["Onpremis", "cloud"]
    let TypeOfOrganisations = ["Law firm", "Corporate legal departmnet"]
    let TimeFrame = ["In the next 12 months", "12 to 24 months", "more than 24 months"]
    let SDFCAccountType = ["Client", "Prospect"]
    let urgency = ["Client", "Prospect"]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // creating gesture recognizers and wiring it with corrresponding views
        
        let tapGesture = UITapGestureRecognizer(target: self, action:#selector(LabelTapGestureHandler(sender:)))
        tapGesture.delegate = self
        tapGesture.numberOfTouchesRequired = 1
        tapGesture.numberOfTapsRequired = 1
        
        ListOfProductsLabel.isUserInteractionEnabled = true
        DeploymentTypeLabel.isUserInteractionEnabled = true
        //OrganisationTypeLabel.isUserInteractionEnabled = true
        //TimeFrameLabel.isUserInteractionEnabled = true
        //AccountTypeLabel.isUserInteractionEnabled = true
        //UrgencyTypeLabel.isUserInteractionEnabled = true
   
        /* adding gestures to the corresponding views */
        
        ListOfProductsLabel.addGestureRecognizer(tapGesture)
        DeploymentTypeLabel.addGestureRecognizer(tapGesture)
        //OrganisationTypeLabel.addGestureRecognizer(tapGesture)
        //TimeFrameLabel.addGestureRecognizer(tapGesture)
        //AccountTypeLabel.addGestureRecognizer(tapGesture)
        //UrgencyTypeLabel.addGestureRecognizer(tapGesture)
        
        
        ListOfProductsLabel.tag = 1
        DeploymentTypeLabel.tag = 2
        //UrgencyTypeLabel.tag = 4
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func LabelTapGestureHandler(sender:UITapGestureRecognizer){
      print(sender.view!.tag)
        GeneratePicker()
    }
    
    
    //labelName:UILabel
    func GeneratePicker() {
        
        let vc = UIViewController()
        vc.preferredContentSize = CGSize(width: 250,height: 300)
        let pickerView = UIPickerView(frame: CGRect(x: 0, y: 0, width: 250, height: 300))
        pickerView.delegate = self
        pickerView.dataSource = self
        vc.view.addSubview(pickerView)
        let editRadiusAlert = UIAlertController(title: "Choose distance", message: "", preferredStyle: UIAlertControllerStyle.alert)
        editRadiusAlert.setValue(vc, forKey: "contentViewController")
        editRadiusAlert.addAction(UIAlertAction(title: "Done", style: .default, handler: nil))
        editRadiusAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(editRadiusAlert, animated: true)
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return IManageProducts.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return IManageProducts[row]
    }
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print("selected ",IManageProducts[row])
    }
    
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        return nil
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 36.0
    }
    // for best use with multitasking , dont use a constant here.
    //this is for demonstration purposes only.
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return 200
    }
    
    
}

