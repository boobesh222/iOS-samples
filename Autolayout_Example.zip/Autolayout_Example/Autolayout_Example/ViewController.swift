//
//  ViewController.swift
//  Autolayout_Example
//
//  Created by Boobesh Balasubramanian on 11/02/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

