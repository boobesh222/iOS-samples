//
//  BarcodeScanner.swift
//  BarcodeScanner
//
//  Created by Boobesh Balasubramanian on 02/05/17.
//  Copyright © 2017 sensiple. All rights reserved.
//

import Foundation
import AVFoundation
import UIKit

class BarcodeScanner:NSObject,AVCaptureMetadataOutputObjectsDelegate{
    
    var videoCaptureDevice: AVCaptureDevice = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
    var device = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
    var output = AVCaptureMetadataOutput()
    var previewLayer: AVCaptureVideoPreviewLayer?
    var captureSession = AVCaptureSession()
    var code: String?
    var callingViewController:UIViewController?
    
    override init() {
        print("designated initializer")
    }
    
    init(viewController:UIViewController) {
        callingViewController = viewController
        super.init()
    }
    
    
    /* Function which setup the camera for scanning the one and 2 dimentional barcodes and supports the Symbolizes according to apple documentation   */
    
    internal func setupCamera(previewViewForScanning:UIView){
        
        
        callingViewController?.view.backgroundColor = UIColor.clear
        let input = try? AVCaptureDeviceInput(device: videoCaptureDevice)
        
        if self.captureSession.canAddInput(input) {
            self.captureSession.addInput(input)
        }
        
        self.previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        
        if let videoPreviewLayer = self.previewLayer {
            videoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
            videoPreviewLayer.frame = previewViewForScanning.bounds
            previewViewForScanning.layer.addSublayer(videoPreviewLayer)
        }
        
        print("camera setted up")
        let metadataOutput = AVCaptureMetadataOutput()
        if self.captureSession.canAddOutput(metadataOutput) {
            self.captureSession.addOutput(metadataOutput)
            
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            print("metadata output delegate added ")
            metadataOutput.metadataObjectTypes = [AVMetadataObjectTypeUPCECode,
                                                  AVMetadataObjectTypeCode39Code,
                                                  AVMetadataObjectTypeCode39Mod43Code,
                                                  AVMetadataObjectTypeEAN8Code,
                                                  AVMetadataObjectTypeCode93Code,
                                                  AVMetadataObjectTypeCode128Code,
                                                  AVMetadataObjectTypePDF417Code,
                                                  AVMetadataObjectTypeAztecCode,
                                                  AVMetadataObjectTypeInterleaved2of5Code,
                                                  AVMetadataObjectTypeITF14Code,
                                                  AVMetadataObjectTypeDataMatrixCode,
                                                  AVMetadataObjectTypeQRCode,
                                                  AVMetadataObjectTypeEAN13Code]
        } else {
            print("Could not add metadata output")
        }
    }

    
    
    /* consecutive methods which starts and stops barcode scanning sessions  */
    
    func startScanningSessionForBarcodes(){
        if (captureSession.isRunning == false) {
            captureSession.startRunning();
        }
    }
    
    func stopScanningSessionForBarcodes(){
        if (captureSession.isRunning == true) {
            captureSession.stopRunning();
        }

    }
    
    
    /* shows the result of barcodes  in alertview  */
    
    func scannedResultAlert(scannedCode:String){
        let userIntimationAlert=UIAlertController(title: "yeppie ", message: "find your code \(scannedCode)", preferredStyle: .alert)
        userIntimationAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        callingViewController!.present(userIntimationAlert, animated: true)
    }
    
    
    /* delegate method which returns the captured output objects */
    
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!) {
        // This is the delegate'smethod that is called when a code is readed
        for metadata in metadataObjects {
            let readableObject = metadata as! AVMetadataMachineReadableCodeObject
            print("barcode type \(readableObject.type)")
            let code = readableObject.stringValue
            callingViewController?.dismiss(animated: true, completion: nil)
            print(code!)
            scannedResultAlert(scannedCode:code!)
        }
        stopScanningSessionForBarcodes()
    }
    
    
    
   
}
