//
//  LocationSearchTable.h
//  i_trackbus
//
//  Created by Boobesh Balasubramanian on 24/07/16.
//  Copyright © 2016 chehkra. All rights reserved.
//
#import <UIKit/UIKit.h>

#import <Foundation/Foundation.h>
@import MapKit;
#import "ViewController.h"

@interface LocationSearchTable :UITableViewController<UISearchResultsUpdating>


@property MKMapView * mapview;
@property id <HandleMapSearch> handleMapSearchDelegate;


@end
