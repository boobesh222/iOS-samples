//
//  DetailsTable+CoreDataProperties.swift
//  EC2task
//
//  Created by Boobesh Balasubramanian on 10/09/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import CoreData


extension DetailsTable {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<DetailsTable> {
        return NSFetchRequest<DetailsTable>(entityName: "DetailsTable");
    }

    @NSManaged public var category: String?
    @NSManaged public var created_by: Int64
    @NSManaged public var created_date: NSDate?
    @NSManaged public var id: String?
    @NSManaged public var key: String?
    @NSManaged public var language_code: String?
    @NSManaged public var last_updated_date: NSDate?
    @NSManaged public var updated_by: NSDate?
    @NSManaged public var value: String?

}
