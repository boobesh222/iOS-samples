//
//  ViewController.swift
//  CameraFunctions
//
//  Created by IPhone Dev on 19/05/17.
//  Copyright © 2017 Sensiple. All rights reserved.
//

import UIKit

class ViewController: UIViewController,CustomImagePickerDelegate {

    var pickerObject:ImagePickerHelper?
    
   
    @IBAction func loadImage(_ sender: UIButton) {
        
        pickerObject?.loadImagePicker(presentingViewController: self,needsEditing: false)

    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
        pickerObject = ImagePickerHelper()
        pickerObject?.setupImagePickerDelegate()
        
        pickerObject?.ImagePickerProtocol = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // custom image picker delegate which delivers the selected image
    
    func selectedPhotoLibraryImage(selectedImage: UIImage) {
        print("protocol method")
        print(selectedImage.size)
        
    }
        
    

}

