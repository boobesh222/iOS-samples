//
//  multipleImagePIckerFramework.h
//  multipleImagePIckerFramework
//
//  Created by IPhone Dev on 24/05/17.
//  Copyright © 2017 Sensiple. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for multipleImagePIckerFramework.
FOUNDATION_EXPORT double multipleImagePIckerFrameworkVersionNumber;

//! Project version string for multipleImagePIckerFramework.
FOUNDATION_EXPORT const unsigned char multipleImagePIckerFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <multipleImagePIckerFramework/PublicHeader.h>


