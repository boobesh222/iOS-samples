//
//  ViewController.h
//  i_trackbus
//
//  Created by Boobesh on 7/7/16.
//  Copyright © 2016 chehkra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@protocol HandleMapSearch <NSObject>

-(void)dropPinZoomIn:(MKPlacemark *)placemark;

@end

@interface ViewController : UIViewController<CLLocationManagerDelegate,HandleMapSearch,MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapview;
@property (strong,atomic) CLLocationManager *clLocationManager;




@end

