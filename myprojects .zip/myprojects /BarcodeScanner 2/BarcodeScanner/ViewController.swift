//
//  ViewController.swift
//  BarcodeScanner
//
//  Created by Boobesh Balasubramanian on 26/04/17.
//  Copyright © 2017 sensiple. All rights reserved.
//

import UIKit
import AVFoundation
import BarcodeFramework

class ViewController: UIViewController,barcodeResultProtocol {
    
    var barcode:BarcodeScanner?
    
    @IBAction func captureBarcode(_ sender: UIButton) {
       // barcode?.startScanningSessionForBarcodes()

        barcode?.setupCamera(previewViewForScanning: self.view, frameWidth: 50 , frameHeight: 50, frameColour: UIColor.green.cgColor)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        barcode = BarcodeScanner()
        barcode?.barcodeProtocol = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        barcode?.startScanningSessionForBarcodes()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        barcode?.stopScanningSessionForBarcodes()
        
    }
    
    /* barcode frameworks result delegate method */
    func scannedBarcodeResult(_ barcode:String){
        scannedResultAlert(scannedCode: barcode)
    }
    
    
    // Alert method which displays alert to the users 
    func scannedResultAlert(scannedCode:String){
        let userIntimationAlert=UIAlertController(title: "Result", message: "find your code \(scannedCode)", preferredStyle: .alert)
        userIntimationAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(userIntimationAlert, animated: true)
    }
    
    
    
}

